nv = size(x, 1);

y = x;
y(P2PVtxIds,:) = p2pDsts;

