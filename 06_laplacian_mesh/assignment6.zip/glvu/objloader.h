#pragma once
#include <vector>
bool readObj(const char *filename, std::vector<float> &vertices, std::vector<int> &faces);



