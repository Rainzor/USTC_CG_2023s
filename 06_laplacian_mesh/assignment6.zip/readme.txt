how to use this code:
1. make sure that the current path in Matlab points to this folder
2. build the glvu.sln project. Run or debug from visual studio
