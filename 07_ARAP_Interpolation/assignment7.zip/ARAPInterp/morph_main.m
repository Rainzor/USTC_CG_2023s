[x,t] = readObj('elephant_s');
y = readObj('elephant_t');


figure('position', [10 40 1210, 840]); subplot(131); drawmesh(t, x);
subplot(133); drawmesh(t, y);
subplot(132); h=drawmesh(t, x);


for w = 0:0.01:1
    %% placeholder: linear interpolating the vertex positions
    z = (1-w)*x + w*y;
    
    %% TODO: finish the ARAP interpolation function
%     z = ARAP_interp(x, y, t, w);

    %% draw the result
    set(h,'vertices',z);
    drawnow; pause(0.01);
end



function h = drawmesh(t, x)
    h = trimesh(t, x(:,1), x(:,2), x(:,1), 'facecolor', 'interp', 'edgecolor', 'k');
    axis equal; axis off; view(2);
end